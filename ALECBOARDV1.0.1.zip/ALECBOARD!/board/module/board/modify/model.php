<?php
class Model {

	private $db;
	private $queArr;
	private $ALECBOARDV1;

	public function __construct($DB, $_query, $_ALECBOARDV1) {
		$this->db = $DB;
		$this->queArr = $_query;
		$this->ALECBOARDV1 = $_ALECBOARDV1;
	}

	public function getBoardInfo($id) {
		$queStr = str_replace('{0}', $id, $this->queArr['get_board_info']);
		$que = $this->db->query($queStr);
		$result = $this->db->fetch($que);
		$this->db->free($que);
		return $result;
	}

	public function getCommentData($id, $target) {
		$queStr = str_replace(array('{0}', '{1}'), array($id, (int)$target), $this->queArr['get_comment_data']);
		$que = $this->db->query($queStr);
		$result = $this->db->fetch($que);
		$this->db->free($que);
		return $result;
	}
}

?>