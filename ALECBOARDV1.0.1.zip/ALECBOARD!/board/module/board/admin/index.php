<?php
if(!defined('GR_BOARD_2')) exit();

$skin = 'basic';
$skinResourcePath = 'module/board/admin/skin/' . $skin;
include 'skin/' . $skin . '/index.php';
?>