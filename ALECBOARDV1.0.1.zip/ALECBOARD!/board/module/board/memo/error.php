<?php
$error = array(
	'msg_no_permission' => '쪽지 사용을 위해선 로그인을 먼저 하셔야 합니다.' ,
	'msg_send_success' => '쪽지를 성공적으로 보냈습니다.' ,
	'msg_unknown_id' => '쪽지를 보낼 상대방의 ID 찾지 못했습니다.' ,
	'msg_send_fail' => '쪽지를 보내지 못했습니다.'
);
?>