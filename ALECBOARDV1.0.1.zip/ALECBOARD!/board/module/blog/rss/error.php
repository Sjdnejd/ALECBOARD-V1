<?php
$error = array(
	'msg_no_permission' => 'RSS 를 볼 수 있는 권한이 없습니다!'
);
?>