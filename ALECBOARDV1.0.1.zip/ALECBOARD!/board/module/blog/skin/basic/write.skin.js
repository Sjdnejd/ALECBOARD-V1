$(function(){
	    
    var gr2write = {
        
        ALECBOARDV1: $("#hiddenInputs > input[name=ALECBOARDV1]").val(),
        dropzone: $("#gr2dndUpload").get(0),
        content: $("#gr2content"),
        hidden: $("#hiddenInputs"),
        jDropzone: $("#gr2dndUpload"),
        writeForm: $("#blogWriteForm").get(0),

        previewImage: function(file) {
            var imgTag = "<img class=\"preview\" src=\"" + file + "\" border=\"0\" title=\"더블 클릭 시 삭제\" />";
            gr2write.jDropzone.append(imgTag);
            var oldContent = gr2write.content.html();
            oldContent += "<br /><br />" + imgTag + "<br /><br />";
            tinymce.activeEditor.execCommand('mceInsertContent', false, oldContent);
        },
        
        linkFile: function(file) {
            var downTag = "<img class=\"download\" src=\"/" + gr2write.ALECBOARDV1 + 
              "/module/blog/skin/basic/images/down.png\" rel=\"/" + gr2write.ALECBOARDV1 + "/download/file/" + file +"\" border=\"0\" />";
            gr2write.jDropzone.append(downTag);
            var oldContent = gr2write.content.html();
            oldContent += "<br /><br />" + downTag + "<br /><br />";
            gr2write.content.html(oldContent);
        },

        readFile: function(files) {
            var formData = new FormData();
            for(var i=0; i<files.length; i++) {
                formData.append("file[]", files[i]);
                gr2write.jDropzone.css("padding", "5px").css("height", "100px");
            }
            
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "/" + gr2write.ALECBOARDV1 + "/blog/upload");
            formData.append("mode", "dnd");
            xhr.send(formData);
            xhr.onreadystatechange = function() {
                if(xhr.readyState == 4 && xhr.status == 200) {
                    var json = eval('(' + xhr.responseText + ')');
                    if(json.status == "error") {
                        var err = json.msg;
                        var msg = "에러 없음";
                        switch(err) {
                            case 1: 
                            case 2: msg = "파일 크기가 너무 큽니다. (ERROR: 2)"; break;
                            case 4: msg = "파일이 업로드 되지 않았습니다. (ERROR: 4)"; break;
                            case 6: msg = "임시 폴더를 잃어버렸습니다. (ERROR: 6)"; break;
                            default: msg = err; break;
                        }
                        alert(msg);
                    } else {
                        for(var f in json.list) {
                            var hash = json.list[f].hash;
                            var real = json.list[f].real;
                            var ext = real.match(/[^\\]*\.(\w+)$/);
                            var extLow = ext[1].toLowerCase();
                            if(extLow == "png" || extLow == "jpg" || extLow == "gif" || extLow == "bmp") {
                                gr2write.previewImage(hash);
                            } else {
                                var path = hash.split('/');
                                gr2write.linkFile(path[ path.length - 1 ]);
                            }
                            gr2write.hidden.append("<input type=\"hidden\" name=\"hashfiles[]\" value=\"" + hash + "\" />");
                            gr2write.hidden.append("<input type=\"hidden\" name=\"realfiles[]\" value=\"" + real + "\" />");
                        }
                    }
                } 
            };
        }
    };
    
    $(document).on("dblclick", "img.preview", function(){
        if(confirm("정말로 삭제 하시겠습니까?")) {
            var img = $(this);
            var path = img.attr("src");
            var pathArr = path.split("/");
            var pathName = pathArr[ pathArr.length - 1 ];
            $.ajax({
                url: "/" + gr2write.ALECBOARDV1 + "/module/blog/upload/delete.php",
                data: "path="+pathName,
                type: "POST",
                dataType: "text",
                success: function(data) {
                    img.remove();
                    alert("본문에 삽입 되었던 그림은 직접 삭제해 주세요.");
                }
            });
        }
    });
        
    gr2write.dropzone.ondragover = function() {
        this.className = "hover"; 
        return false;
    };

    gr2write.dropzone.ondragend = function() {
        this.className = "";
        return false;
    };

    gr2write.dropzone.ondrop = function(e) {
        this.className = "";
        e.preventDefault();
        gr2write.readFile(e.dataTransfer.files);
    };
    
    $("head").append("<script src=\"/" + gr2write.ALECBOARDV1 + "/lib/tinymce/tinymce.min.js\"></script>");
    tinymce.init({
        selector: "textarea#gr2content",
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
            "searchreplace visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"      
        ],
        content_css: "/" + gr2write.ALECBOARDV1 + "/module/blog/skin/basic/editor.css",
        forced_root_block : false,
        setup: function(ed) {
            ed.on('submit', function(e) {
                e.preventDefault();
                var subject = $("input[name=gr2subject]");
                var content = ed.getContent();
                if(subject.val() == "") {
                    alert("글 제목을 입력해 주세요");
                    subject.focus();
                    return false;
                }
                if(content == "") {
                    alert("글 내용을 입력해 주세요");
                    return false;
                }
                $("#blogWriteForm input[name=isVisible]").prop("checked", true);
                gr2write.hidden.append("<input type=\"hidden\" name=\"gr2content\" value=\"" + content.replace(/"/g, "[bigquote]") + "\" />");
                gr2write.writeForm.submit();
                return false;   
            });
        },
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons"
    });
    
    $("#savedraft").click(function(){
    	var content = tinymce.activeEditor.getContent();
        $("#blogWriteForm input[name=isVisible]").prop("checked", false);
        gr2write.hidden.append("<input type=\"hidden\" name=\"gr2content\" value=\"" + content.replace(/"/g, "[bigquote]") + "\" />");
        $("#blogWriteForm").submit();
    });
    
    $("#removepost").click(function(){
    	var uid = $(this).attr("rel");
    	$("#blogWriteForm input[name=deleteThis]").val(uid);
    	$("#blogWriteForm").submit();
    });
    
	$("body").bootstrapMaterialDesign();
	$('[data-toggle="tooltip"]').tooltip();			
});
