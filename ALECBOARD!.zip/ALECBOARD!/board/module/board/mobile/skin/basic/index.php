<?php
if(!defined('GR_BOARD_2')) exit();
include $skinPath . '/header.php';
include $skinPath . '/' . $mobileAction . '.php';
include $skinPath . '/footer.php';
?>
