<?php
$error = array(
	'msg_no_permission' => '관리자 페이지에 접근할 권한이 없습니다' ,
	'msg_delete_board_done' => '게시판이 정상적으로 삭제 되었습니다' ,
	'msg_delete_board_group_done' => '게시판 그룹이 정상적으로 삭제 되었습니다 (소속 게시판들은 기본 그룹으로 소속 변경됨)' ,
	'msg_id_exist' => '실패: 이미 등록된 아이디' ,
	'msg_empty_form' => '실패: 누락된 입력 항목' ,
	'msg_delete_member_done' => '회원 계정이 정상적으로 삭제 되었습니다' ,
	'msg_cant_delete_admin' => '관리자 계정은 삭제 하실 수 없습니다' ,
	'msg_delete_member_group_done' => '회원 그룹이 정상적으로 삭제 되었습니다 (소속 회원들은 기본 그룹으로 소속 변경됨)'
);
?>