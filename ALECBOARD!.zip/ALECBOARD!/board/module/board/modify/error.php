<?php
$error = array(
	'msg_no_permission' => '수정 권한이 없습니다!' ,
	'msg_modify_fail' => '수정 할 수 없었습니다!' ,
	'msg_wrong_target' => '수정 대상을 잘못 지정하였습니다!'
);