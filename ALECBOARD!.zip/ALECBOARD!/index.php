<?php
if(!file_exists('./board/dbinfo.php')) { include './board/install/index.php'; die(); }

$mobile_agent = "/(iPod|iPhone|Android|BlackBerry|SymbianOS|SCH-M\d+|Opera Mini|Windows CE|Nokia|SonyEricsson|webOS|PalmOS)/";

if(preg_match($mobile_agent, $_SERVER['HTTP_USER_AGENT'])){
	echo "Mobile";
	header("location:http://alexleejw.com/board/board-test/mobile/list/1");
}else{
	echo "PC";
	header("location:http://alexleejw.com/board/board-test/list/1");
}

?>

