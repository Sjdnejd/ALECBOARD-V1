<?php
if(!defined('GR_BOARD_2')) exit();

include 'join/query.php';
include 'join/model.php';
include 'join/error.php';

if( $Common->getSessionKey() > 0 ) $Common->error($error['msg_already_logged']);
if(!isset($ext_id)) {
	$moveBackPath = '/';
	$prePath = '/' . $ALECBOARDV1 . '/board';
}
else {
	$moveBackPath = '/' . $ALECBOARDV1 . '/board-' . $ext_id . '/list/1';
	$prePath = '/' . $ALECBOARDV1 . '/board-' . $ext_id;
}

$Model = new Model($DB, $query, $ALECBOARDV1, $Common);

if( array_key_exists('joinProceed', $_POST) ) {
    
    if(empty($_POST['g-recaptcha-response'])) {
        $Common->error($error['msg_spam_google_reject']);
    }
    
	$ret = $Model->joinUs($_POST);
	if($ret == true) {
		header('Location: ' . $moveBackPath);
		exit();
	} elseif($ret == -1) {
		$Common->error($error['msg_empty_form']);
	} else {
		$Common->error($error['msg_id_exist']);
	}
}

$skin = 'basic';
$skinResourcePath = '/' . $ALECBOARDV1 . '/module/' . $ext_module . '/join/skin/' . $skin;
$skinPath = 'module/board/join/skin/' . $skin;

include 'join/skin/'.$skin.'/index.php';

unset($Model, $skinResourcePath, $skinPath, $query);
?>