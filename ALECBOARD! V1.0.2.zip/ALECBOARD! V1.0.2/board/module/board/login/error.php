<?php
$error = array(
	'msg_wrong_input' => '아이디 혹은 비밀번호가 올바르지 않습니다!' ,
	'msg_already_logged' => '이미 로그인 되어 있습니다!' ,
	'msg_not_logged' => '이미 로그아웃 되어 있습니다!'
);
?>