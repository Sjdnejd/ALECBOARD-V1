<?php
$error = array(
	'msg_input_is_empty' => '입력 항목을 다시 확인해 주세요!' ,
	'msg_wrong_parameter' => '잘못된 인수가 전달되었습니다!' ,
	'msg_write_complete' => '댓글을 작성 하였습니다!' ,
	'msg_write_fail' => '글 작성 실패!' ,
	'msg_no_permission' => '글 작성 권한이 없습니다!' ,
	'msg_modify_fail' => '글 수정 실패!' ,
    'msg_spam_google_reject' => '구글  스팸글 방지 시험에 통과하지 못했습니다! 로봇이 아닙니다에 체크해 주세요!' ,
);
?>