<?php 
if(!defined('GR_BOARD_2')) exit(); 

include 'list.php';
?>