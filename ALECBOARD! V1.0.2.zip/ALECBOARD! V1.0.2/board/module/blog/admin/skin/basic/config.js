$(function(){
	$("body").bootstrapMaterialDesign();
	$('[data-toggle="tooltip"]').tooltip();
});		