<?php
define('GR_BOARD_2', true);
define('GR2_VERSION_NUM', 2022);
define('GR2_VERSION_STATE', 'CORE');
define('GR2_VERSION_STR', 'v1.0.2');

$docRootArr = explode('/', $_SERVER['DOCUMENT_ROOT']);
$root = $docRootArr[count($docRootArr) - 2];
$ALECBOARDV1Arr = explode(DIRECTORY_SEPARATOR, dirname(__FILE__));
$ALECBOARDV1 = end($ALECBOARDV1Arr);
if($root == $ALECBOARDV1) $ALECBOARDV1 = '.';
if(!file_exists('dbinfo.php')) { include 'install/index.php'; die(); }

	
@session_save_path('session');
@session_start();

include 'util/common/common.php';
include 'dbinfo.php';
include 'util/db/mysql.php';
include 'common.config.php';
$Common = new Common($ALECBOARDV1);
$DB = new MySQL($db_hostname, $db_username, $db_password, $db_dbname, $db_is_utf8);

if(!isset($_GET['module']) || !isset($_GET['action'])) $Common->error('@page/error/index_access_without_param');
$ext_module = $Common->getPlaneText($_GET['module']);
$ext_action = $Common->getPlaneText($_GET['action']);

include 'module/' . $ext_module . '/index.php';

unset($ALECBOARDV1Arr, $ALECBOARDV1, $Common, $DB, $ext_module, $ext_action, $ext_page, $ext_articleNo, $gr2cfg);
?>