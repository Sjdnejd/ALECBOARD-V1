<?php
header("location:./board");
?>

