<?php
header("location:./board");
?>
