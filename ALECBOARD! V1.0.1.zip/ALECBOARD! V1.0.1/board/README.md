ALECBOARDV1
========

BBS system (based on PHP5+ and HTML5)
PHP5와 HTML5가 적용되어 있는 최신 게시판!

Use community Board or Blog!
커뮤니티 게시판 또는 블로그를 스스로 개설할 수 있는 만능 BBS!

Please contact to joowonlee0704@gmail.com or alexleejw.com 
문의는 joowonlee0704@gmail.com 또는 alexleejw.com 으로 연락 바랍니다.

