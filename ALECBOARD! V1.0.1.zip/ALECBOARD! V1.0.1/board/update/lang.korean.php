<?php
$lang = array(
	'msg_success' => 'ALECBOARDV1 업데이트가 정상적으로 완료 되었습니다!',
	'error_db_connection' => 'MySQL DB에 정상적으로 접근하지 못했습니다.',
	'tooltip_go_first_page' => '첫 화면으로 이동!'
);
?>