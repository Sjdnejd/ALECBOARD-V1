<?php
// Please refer this url: https://www.google.com/recaptcha/ for get your own key.
$gr2cfg['googleRecaptchaApiUrl'] = 'https://www.google.com/recaptcha/api.js';
$gr2cfg['googleRecaptchaSiteKey'] = '';  // Please update this key for your own
$gr2cfg['googleRecaptchaSecretKey'] = '';  // Please update this key for your own (Be sure keep it a secret)
$gr2cfg['googleRecaptchaRequestUrl'] = 'https://www.google.com/recaptcha/api/siteverify';
?>