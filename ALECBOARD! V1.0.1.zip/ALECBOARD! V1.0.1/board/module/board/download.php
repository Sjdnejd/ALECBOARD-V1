<?php
if(!defined('GR_BOARD_2')) exit();
if(!isset($boardLink)) $boardLink = '/' . $ALECBOARDV1 . '/board-' . $ext_id;

include 'download/query.php';
include 'download/model.php';
include 'download/error.php';

if(isset($_GET['articleNo'])) {
	$target = (int)$_GET['articleNo'];
} else {
	$Common->error($error['msg_wrong_access'], $boardLink . '/list/1');
}
$Model = new Model($DB, $query, $ALECBOARDV1);
$fileInfo = $Model->getFileStore($target);
$boardInfo = $Model->getBoardInfo($fileInfo['board_id']);
$userInfo = $Model->getUserInfo($Common->getSessionKey());

if($userInfo['level'] < $boardInfo['view_level']) {
	$Common->error($error['msg_no_permission'], $boardLink . '/list/1');
}

$hash = '..' . $fileInfo['hash_name'];
$realArr = explode('/', $fileInfo['real_name']);
$real = $realArr[ count($realArr) - 1 ];
header('Content-type: file/unknown'); 
header('Content-Length: ' . filesize($hash)); 
header('Content-Disposition: attachment; filename=' . $real);
header('Content-Transfer-Encoding: binary'); 
header('Content-Description: ALECBOARDV1 Generated Data'); 
header('Cache-Control: cache, must-revalidate');  
header('Pragma: no-cache'); 
header('Expires: 0'); 

$fp = fopen($hash, 'rb');
echo fread($fp, filesize($hash));
flush();
fclose($fp);

unset($Model, $error, $query, $fileInfo, $boardInfo, $userInfo, $boardLink, $fp);
?>