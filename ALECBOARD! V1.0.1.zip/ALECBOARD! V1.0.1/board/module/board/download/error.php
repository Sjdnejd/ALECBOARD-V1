<?php
$error = array(
	'msg_no_permission' => '다운로드 할 권한이 없습니다!' ,
	'msg_no_file' => '파일이 없습니다!' ,
	'msg_wrong_access' => '잘못된 접근 입니다.'
);
?>