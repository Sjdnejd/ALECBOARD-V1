<?php
$error = array(
	'msg_no_permission' => '글을 읽을 권한이 없습니다.',
	'msg_secret_post' => '이 글은 비밀글 입니다.'
);
?>