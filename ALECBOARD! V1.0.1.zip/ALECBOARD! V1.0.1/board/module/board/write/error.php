<?php
$error = array(
	'msg_input_is_empty' => '입력 항목을 다시 확인해 주세요.' ,
	'msg_wrong_parameter' => '잘못된 인수가 전달 되었습니다.' ,
	'msg_write_complete' => '글을 작성 하였습니다.' ,
	'msg_write_fail' => '글 작성에 실패 하였습니다. 다시 로그인 후 시도해 보세요.' ,
	'msg_no_permission' => '글 작성 권한이 없습니다.' ,
	'msg_modify_fail' => '글 수정에 실패 하였습니다. 다시 로그인 후 시도해 보세요.' ,
    'msg_spam_google_reject' => '구글 스팸 테스트에 실패 하였습니다. 자동 입력 방지를 위해 다시 시도해 주세요.' ,
	'msg_file_size_exceeded' => '첨부 파일의 크기가 허용 용량을 초과 하였습니다.' ,
);
?>