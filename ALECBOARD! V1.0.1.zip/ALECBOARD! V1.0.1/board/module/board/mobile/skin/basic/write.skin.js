$(function(){
	$("#gr2content").css("height", "10rem");
});	