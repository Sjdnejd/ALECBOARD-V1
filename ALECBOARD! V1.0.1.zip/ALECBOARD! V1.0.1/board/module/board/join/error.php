<?php
$error = array(
	'msg_id_exist' => '동일한 아이디가 이미 존재 합니다 다른 걸로 바꾸셔야 합니다.' ,
	'msg_already_logged' => '이미 로그인 되어 있습니다!' ,
	'msg_empty_form' => '입력 해야 할 필드 중 일부가 비어 있습니다. 모두 다 채워 주세요.' ,
    'msg_spam_google_reject' => '로봇 입력 방지에 실패 하였습니다. "로봇이 아닙니다" 에 체크해 주세요!' ,
);
?>