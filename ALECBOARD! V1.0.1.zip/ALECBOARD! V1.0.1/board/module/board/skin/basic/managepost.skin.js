$(function(){
	$("#boardManageForm").on("submit", function(e){
		return true;
	});
	
	$("body").bootstrapMaterialDesign();
	$('[data-toggle="tooltip"]').tooltip();
});
