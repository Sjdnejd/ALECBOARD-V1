$(function(){
	$("#gr2searchForm").submit(function(event){
		event.preventDefault();
		var ALECBOARDV1 = $("#ALECBOARDV1").attr("rel");
		var id = $("#gr2searchForm input[name=boardId]").val();
		var option = $("#gr2searchForm select[name=option]").val();
		var value = $("#gr2searchForm input[name=value]").val();
		var page = $("#gr2searchForm input[name=page]").val();
		if($.trim(value) == "") {
			alert("검색어가 비어 있습니다. 다시 확인해 주세요!");
			return;
		}       
		location.href = "/" + ALECBOARDV1 + "/board-" + id + "/search/" + option + "/" + value + "/" + page;
	});  
	
	$("#checkAllPost").click(function(){
		$(".list .check input[type=checkbox]").each(function(){
			this.checked = !this.checked;
		});
	});
	
	$("#managePosts").click(function(){
		var isChecked = false;
		$(".list .check input[type=checkbox]").each(function(){
			if(!!this.checked == true) isChecked = true;
		});
		
		if(!isChecked) {
			$("#modalDlgLabel").text("Notice");
			$("#modalDlgContent").text("관리할 게시글을 하나 이상 선택 하세요!");
			$("#modalDlg").modal();
			return;
		}		
		$("#managePostForm").submit();
	});
	
	$("body").bootstrapMaterialDesign();
	$('[data-toggle="tooltip"]').tooltip();
});
