<?php 
if(!defined('GR_BOARD_2')) exit();
$option = $Common->getPlaneText($_GET['option']);
$value = $Common->getPlaneText($_GET['value']);
include 'list.php'; 
?>
