<?php
$error = array(
	'msg_no_permission' => '삭제 권한이 없습니다!' ,
	'msg_delete_fail' => '삭제 할 수 없었습니다!' ,
	'msg_wrong_target' => '삭제 대상을 잘못 지정하였습니다!' ,
	'confirm_comment_delete' => '아래의 댓글을 정말로 삭제 하시겠습니까?' ,
	'confirm_post_delete' => '글 삭제 시 첨부 파일 및 댓글까지 모두 삭제 됩니다. 정말로 아래의 글을 삭제 하시겠습니까?'
);
?>