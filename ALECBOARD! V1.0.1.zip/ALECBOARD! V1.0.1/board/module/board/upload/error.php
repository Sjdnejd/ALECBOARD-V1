<?php
$error = array(
	'msg_no_permission' => '파일을 업로드 할 권한이 없습니다',
	'msg_need_login' => '로그인이 필요한 기능 입니다',
	'msg_failed_upload' => '파일 업로드에 실패 하였습니다'
);
?>