<?php 
if(!defined('GR_BOARD_2')) exit();
$searchValue = $Common->getPlaneText($_GET['value']);
include 'list.php'; 
?>
