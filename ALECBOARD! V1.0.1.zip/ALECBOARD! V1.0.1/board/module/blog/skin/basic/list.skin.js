$(function(){
    $("#blogSearchForm").submit(function (e) {
        e.preventDefault();
        var value = $("#blogSearchText").val();
        if ($.trim(value) == "") {
            alert("검색어가 비어 있습니다!");
            return false;
        }
        var ALECBOARDV1 = $(this).attr("rel");
        location.href = "/" + ALECBOARDV1 + "/blog-text/search/all/" + value + "/1";
        return false;
    });
    
	$("body").bootstrapMaterialDesign();
	$('[data-toggle="tooltip"]').tooltip();			
});