<?php
$error = array(
	'msg_no_permission' => '관리자 페이지에 접근할 권한이 없습니다',
	'msg_config_saved' => '설정이 저장 되었습니다',
	'msg_config_failed' => '설정을 저장 하지 못했습니다',
	'msg_link_failed' => '링크를 저장 하지 못했습니다',
	'msg_category_minimum_count' => '카테고리는 최소 1개 이상 있어야 합니다 (삭제 불가)',
	'msg_category_failed' => '카테고리 저장에 실패 하였습니다 (중복된 분류명 혹은 유효하지 않은 분류명)'
);
?>