<?php
if(!defined('GR_BOARD_2')) exit();

$blogCategory = $ext_articleNo;
include 'list.php';
?>