<?php
$error = array(
	'msg_no_permission' => '삭제 권한이 없습니다!' ,
	'msg_delete_fail' => '삭제 할 수 없었습니다!' ,
	'msg_wrong_target' => '삭제 대상을 잘못 지정하였습니다!'
);